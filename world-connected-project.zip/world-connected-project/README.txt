Data Sources:

Population data:
HYDE (2023); Gapminder (2022); UN WPP (2024) – with major processing by Our World in Data. “Population” [dataset]. PBL Netherlands Environmental Assessment Agency, “History Database of the Global Environment 3.3”; Gapminder, “Population v7”; United Nations, “World Population Prospects”; Gapminder, “Systema Globalis” [original data]. Retrieved from: https://ourworldindata.org/grapher/population

Internet users data:
Hannah Ritchie, Edouard Mathieu, Max Roser and Esteban Ortiz-Ospina (2023) - “Internet” Published online at OurWorldinData.org. Retrieved from: 'https://ourworldindata.org/internet' [Online Resource]

Number of internet users worldwide from 2005 to 2024 (in millions), Statistica
https://www.statista.com/statistics/273018/number-of-internet-users-worldwide/
